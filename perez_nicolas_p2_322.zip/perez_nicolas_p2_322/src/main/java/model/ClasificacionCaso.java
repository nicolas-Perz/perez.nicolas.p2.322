
package model;


public enum ClasificacionCaso {
    
    APERTURA_DIMENSIONAL,
    SUJETO_PSIQUICO,
    ENTIDAD_HOSTIL,
    FENOMENO_ELECTROMAGNETICO,
    DESAPARICION,
    CONFIDENCIAL
    
}
