
package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class RegistroHawkins<T> implements Serializable {
    
    private List<T> lista = new ArrayList<>();
    
    public void agregar(T elem) {
        lista.add(elem);
    }
    
    public T obtener(int indice){
        return lista.get(indice);
    }
    
    public void eliminar(int indice){
        lista.remove(indice);
    }
    
    public List<T> filtrar(List<T> lista, T filtro){
        List<T> toReturn = new ArrayList<>();
        
        for(T e : lista){
            if(e == filtro){
                toReturn.add(e);
            }
        }
        return toReturn;
    }
    
}
