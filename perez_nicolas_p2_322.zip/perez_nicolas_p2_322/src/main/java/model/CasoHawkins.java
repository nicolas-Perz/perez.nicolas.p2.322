
package model;

public class CasoHawkins implements Comparable<CasoHawkins>{
    //orden natural id ascendente
    
    private int id;
    private String titulo;
    private String investigador;
    private ClasificacionCaso clasificacion;

    public CasoHawkins(int id, String titulo, String investigador, ClasificacionCaso clasificacion) {
        this.id = id;
        this.titulo = titulo;
        this.investigador = investigador;
        this.clasificacion = clasificacion;
    }
    
    
    
    @Override
    public int compareTo(CasoHawkins o) {
        return Integer.compare(id,o.id);
    }
    
}
