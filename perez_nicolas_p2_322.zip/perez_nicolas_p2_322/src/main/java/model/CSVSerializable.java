
package model;

public interface CSVSerializable{
    
}
