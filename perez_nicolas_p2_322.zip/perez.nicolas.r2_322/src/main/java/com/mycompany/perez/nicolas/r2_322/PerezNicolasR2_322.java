
package com.mycompany.perez.nicolas.r2_322;

import java.io.IOException;
import model.CasoHawkins;
import model.ClasificacionCaso;
import serviceCasos.RegistroHawkins;

public class PerezNicolasR2_322 {

    public static void main(String[] args) {
        
        try {
                RegistroHawkins<CasoHawkins> registro = new RegistroHawkins<>();

                registro.agregar(new CasoHawkins(1, "Apertura cerca del laboratorio", "Dr.Brenner", ClasificacionCaso.APERTURA_DIMENSIONAL));
                registro.agregar(new CasoHawkins(2, "Actividad psíquica elevada", "Dr.Owens", ClasificacionCaso.SUJETO_PSIQUICO));
                registro.agregar(new CasoHawkins(3, "Rastros de entidad en Hawkins", "JimHopper", ClasificacionCaso.ENTIDAD_HOSTIL));
                registro.agregar(new CasoHawkins(4, "Señales electromagnéticas inusuales","Nancy Wheeler", ClasificacionCaso.FENOMENO_ELECTROMAGNETICO));
                registro.agregar(new CasoHawkins(5, "Desaparición de joven en bosque","Joyce Byers", ClasificacionCaso.DESAPARICION));
                
                System.out.println("Casos registrados:");
                registro.paraCadaElemento( (a) -> {System.out.println(a);} );
                
                System.out.println("\nCasos tipo SUJETO_PSIQUICO:");
                registro.filtrar( (a) -> { return a.getClasificacion().equals(ClasificacionCaso.SUJETO_PSIQUICO); } )
                        .forEach( (a) -> {System.out.println(a);} );

                System.out.println("\nCasos que contienen 'portal':");
                registro.filtrar( (a) -> { return  a.getTitulo().toLowerCase().contains("portal"); } )
                        .forEach( (a) -> { System.out.println(a); } );

                System.out.println("\nCasos ordenados por ID:");
                registro.ordenar( (a,b) -> { return Integer.compare(a.getId(), b.getId()); } );
                registro.paraCadaElemento( (a) -> { System.out.println(a); } );

                System.out.println("\nCasos ordenados por título:");
                registro.ordenar( (a,b) -> { return a.getTitulo().compareTo(b.getTitulo()); } );
                registro.paraCadaElemento( (a) -> { System.out.println(a); } );

                registro.guardarEnArchivo("src\\main\\java\\resources\\casos.bin");

                RegistroHawkins<CasoHawkins> cargado = new RegistroHawkins<>();
                cargado.cargarDesdeArchivo("src\\main\\java\\resources\\casos.bin");

                System.out.println("\nCasos cargados desde archivo binario:");
                cargado.paraCadaElemento( (a) -> {System.out.println(a);} );

                registro.guardarEnCSV("src\\main\\java\\resources\\casos.csv");
                cargado.cargarDesdeCSV("src\\main\\java\\resources\\casos.csv", (a) -> { return CasoHawkins.fromCSV(a); } );

                System.out.println("\nCasos cargados desde archivo CSV:");
                cargado.paraCadaElemento( (a) -> {System.out.println(a); } );

            } catch (IOException | ClassNotFoundException e) {
                System.err.println("Error: " + e.getMessage());
            }
        }
    }
