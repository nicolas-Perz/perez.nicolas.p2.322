
package model;

import persistencia.CSVSerializable;

public class CasoHawkins implements Comparable<CasoHawkins>, CSVSerializable{

    private int id;
    private String titulo;
    private String investigador;
    private ClasificacionCaso clasificacion;

    public CasoHawkins(int id, String titulo, String investigador, ClasificacionCaso clasificacion) {
        this.id = id;
        this.titulo = titulo;
        this.investigador = investigador;
        this.clasificacion = clasificacion;
    }

    @Override
    public String toString() {
        return "CasoHawkins{" + "id=" + id + ", titulo=" + titulo + ", investigador=" + investigador + ", clasificacion=" + clasificacion + '}';
    }

    @Override
    public int compareTo(CasoHawkins o) {
        return Integer.compare(id, o.id);
    }

    @Override
    public String toCSV() {
        return id + "," + titulo + "," + investigador + "," + clasificacion;
    }
    
    
    public static CasoHawkins fromCSV(String lineaCSV){
        String[] atributos = lineaCSV.split(",");
        return new CasoHawkins(Integer.parseInt(atributos[0]),atributos[1],atributos[2],ClasificacionCaso.valueOf(atributos[3]));
    }

    public int getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getInvestigador() {
        return investigador;
    }

    public ClasificacionCaso getClasificacion() {
        return clasificacion;
    }
    
    
    
}
