
package serviceCasos;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import model.CasoHawkins;
import persistencia.CSVSerializable;

public class RegistroHawkins <T extends CSVSerializable> {

    private List<T> registro = new ArrayList<>();
    
    public void agregar(T item){
        registro.add(item);
    }
    
    public T obtener(int indice){
        return registro.get(indice);
    }
    
    public void eliminar(T item){
        registro.remove(item);
    }
    
    public List<T> filtrar(Predicate<T> filtro){
        
        List<T> lista = new ArrayList<>();
        
        for(T item : registro){
            if(filtro.test(item)){
                lista.add(item);
            }
        }
        return lista;
    }
    
    public void ordenar(Comparator<T> cmp){
        registro.sort(cmp);
    }
    
    //guardar y cargar binario
    public void guardarEnArchivo(String path) throws IOException{
        try (ObjectOutputStream serializador = new ObjectOutputStream(new FileOutputStream(path))) {
            
            serializador.writeObject(registro);
            
        } catch(IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
    
    public void cargarDesdeArchivo(String path) throws IOException, ClassNotFoundException{
        
        try (ObjectInputStream deserializador = new ObjectInputStream(new FileInputStream(path))){
            
            registro =  (List<T>) deserializador.readObject();
            
        } catch(ClassNotFoundException | IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
    
    //guardar y cargar csv
    public void guardarEnCSV(String path) throws IOException{
        
        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(path))) {
            
            for(T item : registro){
                escritor.write(item.toCSV() + "\n");
            }
            
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        
    }
    
    public void cargarDesdeCSV(String path, Function<String,T> accion) throws IOException{
        registro.clear();
        
        try (BufferedReader lector = new BufferedReader(new FileReader(path))) {
            
            String linea = lector.readLine();
            while ((linea = lector.readLine()) != null){
                registro.add(accion.apply(linea));
            }
            
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
    
    public void paraCadaElemento(Consumer<? super T> accion){
        for(T item : registro){
            accion.accept(item);
        }
    }
    
}
